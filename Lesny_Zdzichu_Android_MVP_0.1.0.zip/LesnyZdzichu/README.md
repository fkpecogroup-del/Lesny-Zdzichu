# Leśny Zdzichu — Android MVP (0.1.0)

To jest pierwszy, działający zakres projektu Android w Kotlinie + Jetpack Compose.

## Co zawiera prototyp
- lokalny poradnik (bez połączenia z internetem),
- wyszukiwarkę tolerującą polskie znaki i ich brak (np. `rozpalka` / `rozpałka`),
- kategorie i szczegóły porad,
- ulubione zapisywane lokalnie,
- notatki zapisywane lokalnie,
- ekran forum jako jawny placeholder przyszłej części online.

Aplikacja nie deklaruje, że forum lub konta już działają. Wymagają serwera, rejestracji, moderacji i polityki prywatności.

## Budowanie APK
1. Zainstaluj Android Studio (wersja z obsługą Android Gradle Plugin 8.7.3).
2. Otwórz folder `LesnyZdzichu` jako projekt.
3. Poczekaj na synchronizację Gradle i pobranie zależności.
4. Wybierz **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK znajdziesz w `app/build/outputs/apk/debug/app-debug.apk`.

Wymagane: JDK 17, Android SDK Platform 35, Android SDK Build-Tools.

## Ważne
To jest prototyp 0.1.0, nie finalny poradnik ratowniczy. Treści wymagają dalszej redakcji i przeglądu eksperckiego przed publikacją jako kompletna baza terenowa. W szczególności nie identyfikuj grzybów ani roślin do spożycia na podstawie aplikacji. W nagłym zagrożeniu dzwoń pod 112.

## Źródła startowe do weryfikacji treści
- Państwowa Straż Pożarna — zasady ognisk: https://www.gov.pl/web/kgpsp/zasady-organizacji-i-rozpalania-ognisk2
- Państwowa Straż Pożarna — pożary lasów: https://www.gov.pl/web/kgpsp/pozary-lasow
- Lasy Państwowe — biwakowanie: https://www.lasy.gov.pl/pl/informacje/faq/biwakowanie
- CDC — uzdatnianie wody podczas wędrówek: https://www.cdc.gov/drinking-water/prevention/water-treatment-hiking-camping-traveling.html
- Rządowe Centrum Bezpieczeństwa — bezpieczna zima: https://www.gov.pl/web/rcb/bezpieczna-zima2

## Kolejne etapy
1. Rozbudować bazę do setek opracowanych haseł i dodać źródła/wersjonowanie.
2. Dodać ilustracje i spójny projekt graficzny zgodny z referencją użytkownika.
3. Dodać testy, eksport/import notatek i kopię zapasową.
4. Zaprojektować backend forum: konta, wątki, zdjęcia, zgłoszenia, moderacja i zabezpieczenia.
5. Przetestować na kilku urządzeniach i przygotować wydanie podpisane.
