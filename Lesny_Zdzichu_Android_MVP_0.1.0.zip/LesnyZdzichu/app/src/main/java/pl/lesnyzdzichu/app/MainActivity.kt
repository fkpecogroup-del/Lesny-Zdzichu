package pl.lesnyzdzichu.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import java.text.Normalizer

private val Forest = Color(0xFF17251D)
private val Moss = Color(0xFF294536)
private val Gold = Color(0xFFC6A66A)
private val Paper = Color(0xFFF2EFE6)
private val Ink = Color(0xFF202820)

data class Tip(
    val title: String, val category: String, val summary: String,
    val best: String, val alternatives: String, val steps: String,
    val caution: String, val tags: String
)

private val tips = listOf(
    Tip("Rozpałka w terenie", "Ogień", "Drobny, suchy materiał, który łatwo zajmuje się od iskry lub płomienia.",
        "Włóknista, sucha kora brzozy z już leżącego, martwego drewna; cienkie suche szczapki i naturalne włókna.",
        "Suche trawy, drobne włókna martwych roślin, żywiczne drzazgi z martwego drewna. Zbieraj tylko tam, gdzie jest to dozwolone i bez niszczenia żywych drzew.",
        "1. Przygotuj mały pęczek bardzo drobnej rozpałki.\n2. Obok ułóż cienkie patyczki, potem coraz grubsze szczapki.\n3. Zapewnij dopływ powietrza.\n4. Dokładaj opał stopniowo, nie zasypuj małego płomienia.",
        "Ognia używaj wyłącznie w miejscach do tego wyznaczonych i zgodnie z aktualnymi zakazami. Nie odrywaj kory z żywych drzew. Miej wodę lub piasek do ugaszenia.", "rozpałka,rozpalka,kora brzozowa,ogień,krzesiwo"),
    Tip("Ognisko – bezpieczeństwo i prawo", "Ogień", "Ogień w terenie wymaga legalnego miejsca, nadzoru i możliwości całkowitego ugaszenia.",
        "Korzystaj z wyznaczonego, przygotowanego paleniska na terenie, gdzie ognisko jest dozwolone.",
        "Jeśli nie ma legalnego paleniska, zrezygnuj z otwartego ognia. Użyj kuchenki turystycznej tylko tam, gdzie jej używanie jest dozwolone.",
        "1. Sprawdź lokalne zakazy i stopień zagrożenia pożarowego.\n2. Upewnij się, że miejsce jest wyznaczone.\n3. Nie zostawiaj ognia bez nadzoru.\n4. Zalej żar, wymieszaj popiół i sprawdź dłonią z bezpiecznej odległości, czy nie emituje ciepła.",
        "W Polsce nie wolno rozniecać ognia w lesie i do 100 m od jego granicy poza miejscami wyznaczonymi. Przy zagrożeniu pożarowym stosuj się do zakazów. W razie pożaru oddal się i dzwoń 112.", "ognisko,ogień,ognisko w lesie,palenisko,pożar"),
    Tip("Woda z potoku – uzdatnianie", "Woda", "Przejrzysta woda ze strumienia nadal może zawierać drobnoustroje.",
        "Najpewniejsze w warunkach terenowych jest zagotowanie wody do mocnego wrzenia.",
        "Użyj sprawnego filtra turystycznego zgodnie z instrukcją producenta, a jeśli to możliwe po filtracji dodatkowo zdezynfekuj wodę.",
        "1. Wybierz możliwie czyste źródło, z dala od zabudowań, pól i padłych zwierząt.\n2. Mętną wodę odstaw do osadzenia i przefiltruj przez czystą tkaninę.\n3. Doprowadź do intensywnego wrzenia przez co najmniej 1 minutę.\n4. Ostudź i przechowuj w czystym, zamkniętym naczyniu.",
        "Gotowanie nie usuwa paliw, metali ciężkich ani toksycznych chemikaliów. Wody o podejrzanym zapachu, tęczowej powłoce lub w pobliżu skażenia nie pij – znajdź inne źródło.", "woda,uzdatnianie,gotowanie,filtr,źródło,potok"),
    Tip("Schronienie awaryjne", "Biwak", "Priorytetem jest osłona przed wiatrem, deszczem i utratą ciepła.",
        "Tarp lub płachta biwakowa rozpięta stabilnie między punktami mocowania, z dala od zagrożeń.",
        "Awaryjnie wykorzystaj folię NRC jako dodatkową warstwę osłonową, ale nie traktuj jej jako pełnego schronienia. Naturalne osłony wybieraj bez łamania gałęzi i niszczenia roślin.",
        "1. Wybierz suche, stabilne miejsce.\n2. Unikaj zagłębień, koryt potoków, martwych drzew i wiszących konarów.\n3. Ustaw wejście z dala od dominującego wiatru.\n4. Odizoluj się od podłoża karimatą lub suchą warstwą izolacyjną.",
        "Nie rozbijaj obozu pod suchymi konarami ani w miejscach zagrożonych zalaniem. Nie śpij w zamkniętym schronieniu z palnikiem lub ogniskiem – grozi to zatruciem tlenkiem węgla.", "biwak,schronienie,tarp,szałas,nocleg,hamak"),
    Tip("Ochrona przed wychłodzeniem", "Survival", "Wychłodzenie może wystąpić także przy dodatniej temperaturze, zwłaszcza gdy ubranie jest mokre i wieje wiatr.",
        "Ogranicz utratę ciepła: osłoń się od wiatru, zdejmij mokre warstwy jeśli masz suche, załóż izolację i odizoluj się od ziemi.",
        "Jeśli nie masz suchej odzieży, osłoń mokre warstwy zewnętrzną barierą przeciwwiatrową i wezwij pomoc, gdy stan się pogarsza.",
        "1. Przerwij dalsze wychładzanie i znajdź osłonięte miejsce.\n2. Delikatnie osusz i okryj osobę.\n3. Ogrzewaj stopniowo, szczególnie tułów.\n4. Ciepły słodki napój podaj tylko osobie w pełni przytomnej i mogącej bezpiecznie połykać.\n5. Przy splątaniu, senności lub zaburzeniach świadomości dzwoń 112.",
        "Nie podawaj alkoholu, nie rozcieraj kończyn i nie ogrzewaj gwałtownie. Osoba nieprzytomna wymaga pilnej pomocy medycznej.", "wychłodzenie,hipotermia,zima,ciepło,ubranie"),
    Tip("Nawigacja, gdy zgubisz szlak", "Nawigacja", "Najważniejsze jest zatrzymanie się i uniknięcie pogłębiania błędu.",
        "Zatrzymaj się, sprawdź mapę i kompas, odtwórz ostatni pewny punkt trasy.",
        "Jeśli nie potrafisz bezpiecznie ustalić pozycji, pozostań w bezpiecznym miejscu i wezwij pomoc. Telefon może mieć GPS bez zasięgu, jeśli mapa jest pobrana offline.",
        "1. Zatrzymaj marsz.\n2. Zadbaj o ciepło, wodę i widoczność.\n3. Sprawdź ostatni znany punkt na mapie.\n4. Nie skracaj drogi przez nieznany teren.\n5. W razie zagrożenia zadzwoń 112 i podaj współrzędne, jeśli je znasz.",
        "Nie polegaj wyłącznie na baterii telefonu. Przed wyjściem pobierz mapy offline, zapisz trasę i poinformuj bliską osobę o planie.", "mapa,kompas,nawigacja,zagubienie,szlak"),
    Tip("Zestaw awaryjny na jednodniową wyprawę", "Wyposażenie", "Mały zestaw zwiększa szanse na bezpieczny powrót przy zmianie pogody lub kontuzji.",
        "Woda, dodatkowa warstwa odzieży, latarka, naładowany telefon, powerbank, mapa, kompas i podstawowa apteczka.",
        "Dostosuj wyposażenie do pory roku, długości trasy, terenu i doświadczenia. Dodaj folię NRC, gwizdek, zapas jedzenia i środki do uzdatniania wody.",
        "1. Sprawdź prognozę i ostrzeżenia.\n2. Zapisz trasę i godzinę powrotu.\n3. Sprawdź baterię i oświetlenie.\n4. Spakuj apteczkę oraz warstwę przeciwdeszczową.\n5. Powiedz komuś, dokąd idziesz.",
        "Nie traktuj listy jako gwarancji bezpieczeństwa. W górach i trudnym terenie potrzebne może być znacznie bogatsze wyposażenie.", "ekwipunek,plecak,apteczka,wyposażenie,zestaw"),
    Tip("Rośliny i grzyby – zasada bezpieczeństwa", "Jedzenie", "Nie jedz roślin ani grzybów na podstawie niepewnego rozpoznania.",
        "Spożywaj wyłącznie gatunki rozpoznane z całkowitą pewnością przez kompetentną osobę i zgodnie z lokalnymi przepisami.",
        "Gdy masz wątpliwości, nie zbieraj i nie jedz. Korzystaj z zapakowanej żywności awaryjnej.",
        "1. Nie polegaj na pojedynczej cesze, kolorze ani aplikacji do rozpoznawania.\n2. Nie próbuj nieznanych roślin „na mały kęs”.\n3. Nie zakładaj, że gotowanie neutralizuje wszystkie toksyny.\n4. W razie spożycia podejrzanego gatunku skontaktuj się pilnie z pomocą medyczną.",
        "Pomyłki mogą prowadzić do ciężkich zatruć, także śmiertelnych. Aplikacja nie służy do potwierdzania jadalności gatunków.", "jedzenie,rośliny,jadalne,grzyby,zatrucie"),
    Tip("Węzły – podstawy", "Bushcraft", "Węzeł dobieraj do obciążenia, materiału liny i warunków; sprawdzaj go przed użyciem.",
        "Do prostych mocowań biwakowych naucz się poprawnie wiązać wyblinkę, półsztyk i węzeł ratowniczy, ćwicząc na ziemi.",
        "Użyj taśm i odciągów przeznaczonych do biwakowania, jeśli nie masz pewności co do węzła.",
        "1. Ćwicz na krótkim odcinku liny.\n2. Dociągnij węzeł i sprawdź, czy się nie przesuwa.\n3. Zostaw odpowiedni zapas końcówki.\n4. Kontroluj mocowanie po zmianie obciążenia.",
        "Nie używaj amatorskich węzłów do wspinaczki, asekuracji ani ratownictwa. Do tych zastosowań wymagane jest szkolenie i certyfikowany sprzęt.", "węzły,wezel,lina,mocowanie,tarp"),
    Tip("Gotowanie w terenie", "Jedzenie", "Planuj posiłki proste, lekkie i możliwe do przygotowania bez ryzykownego ognia.",
        "Kuchenka turystyczna używana zgodnie z instrukcją, w dozwolonym i dobrze wentylowanym miejscu.",
        "Gotowe posiłki niewymagające gotowania lub żywność o wysokiej wartości energetycznej.",
        "1. Sprawdź lokalne ograniczenia dotyczące palników.\n2. Stabilnie ustaw kuchenkę na niepalnym podłożu.\n3. Zabezpiecz ją przed przewróceniem.\n4. Po użyciu zakręć zawór i poczekaj aż sprzęt ostygnie.",
        "Nigdy nie używaj kuchenki w namiocie ani zamkniętym schronieniu. Ryzyko pożaru i zatrucia tlenkiem węgla.", "gotowanie,jedzenie,kuchenka,posiłek,biwak"),
    Tip("Deszcz i mokre drewno", "Ogień", "W deszczu najważniejsze jest znalezienie suchego materiału i ochrona przygotowanej rozpałki.",
        "Szukaj martwych, stojących suchych gałęzi lub suchego wnętrza większego martwego kawałka drewna, bez łamania żywych drzew.",
        "Jeśli warunki są złe albo ogień jest niedozwolony, zrezygnuj z niego i użyj bezpiecznego źródła ciepła/posiłku.",
        "1. Przechowuj rozpałkę pod osłoną.\n2. Rozszczep martwe drewno, aby dotrzeć do suchszego wnętrza.\n3. Przygotuj zapas drobnych szczapek.\n4. Rozpalaj tylko w legalnym miejscu i przy bezpiecznych warunkach.",
        "Nie rozpalaj ognia podczas silnego wiatru, suszy ani obowiązujących zakazów. Nie ścinaj i nie okaleczaj żywych drzew.", "deszcz,mokre drewno,rozpałka,rozpalka,ogień"),
    Tip("Wezwanie pomocy w lesie", "Survival", "Przy realnym zagrożeniu życia lub zdrowia dzwoń pod 112.",
        "Przekaż dyspozytorowi: co się stało, ile osób potrzebuje pomocy, dokładną lokalizację i stan poszkodowanych.",
        "Jeśli nie ma zasięgu, spróbuj przemieścić się na otwartą przestrzeń lub wyżej, ale tylko jeśli jest to bezpieczne. Wysyłaj lokalizację bliskim, gdy odzyskasz łączność.",
        "1. Zadzwoń 112.\n2. Podaj współrzędne GPS lub nazwę szlaku i najbliższy punkt.\n3. Nie rozłączaj się, dopóki dyspozytor nie zakończy rozmowy.\n4. Zabezpiecz miejsce i oszczędzaj baterię.",
        "Nie zakładaj, że aplikacja offline zastąpi numer alarmowy lub ratowników. W sytuacji zagrożenia nie zwlekaj z wezwaniem pomocy.", "112,pomoc,ratunek,telefon,awaria"),
    Tip("Wybór miejsca biwaku", "Biwak", "Dobre miejsce ogranicza ryzyko zalania, spadających gałęzi i ekspozycji na wiatr.",
        "Wybierz legalne miejsce biwakowe, stabilne, suche, poza korytami cieków i z dala od martwych drzew.",
        "Jeżeli nie możesz znaleźć bezpiecznego miejsca, zmień lokalizację zamiast rozbijać obóz w ryzykownym punkcie.",
        "1. Sprawdź, czy biwakowanie jest dozwolone.\n2. Oceń podłoże i odpływ wody.\n3. Spójrz w górę – oceń konary i drzewa.\n4. Unikaj skarp, urwisk, dolin zalewowych i ścieżek zwierząt.\n5. Zostaw miejsce w stanie niepogorszonym.",
        "Nie biwakuj w miejscach objętych zakazem, na uprawach leśnych ani w parkach narodowych poza zasadami udostępniania.", "biwak,miejscówka,nocleg,obóz,namiot"),
    Tip("Podstawy pierwszej pomocy", "Pierwsza pomoc", "Najpierw zadbaj o własne bezpieczeństwo, potem oceń stan poszkodowanego i wezwij pomoc.",
        "W razie poważnego urazu, utraty przytomności, problemów z oddychaniem lub silnego krwawienia dzwoń 112.",
        "Jeśli jesteś przeszkolony, działaj w granicach swoich umiejętności i stosuj się do poleceń dyspozytora.",
        "1. Upewnij się, że miejsce jest bezpieczne.\n2. Sprawdź reakcję i prawidłowy oddech.\n3. Wezwij 112 lub poproś konkretną osobę o telefon.\n4. Przy braku prawidłowego oddechu rozpocznij RKO zgodnie z instrukcjami dyspozytora i użyj AED, jeśli jest dostępne.",
        "Ta krótka karta nie zastępuje kursu pierwszej pomocy. W nagłym zagrożeniu dzwoń 112 i wykonuj polecenia dyspozytora.", "pierwsza pomoc,rko,uraz,krwawienie,112")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ForestApp() }
    }
}

@Composable
fun ForestApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("zdzichu_local", 0) }
    var page by remember { mutableStateOf("Start") }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Tip?>(null) }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()) }
    var notes by remember { mutableStateOf(prefs.getString("notes", "") ?: "") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, secondary = Moss, background = Forest, surface = Color(0xFF22352A),
        onPrimary = Forest, onSecondary = Color.White, onBackground = Paper, onSurface = Paper
    )) {
        Surface(Modifier.fillMaxSize(), color = Forest) {
            Column {
                Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp)) {
                    Text("🌲 LEŚNY ZDZICHU", fontSize = 25.sp, fontWeight = FontWeight.Black, color = Gold)
                    Text("Leśny niezbędnik • działa offline", color = Paper.copy(alpha = .75f), fontSize = 13.sp)
                }
                if (selected != null) {
                    TipDetail(selected!!, favorites.contains(selected!!.title), {
                        val set = favorites.toMutableSet()
                        if (!set.add(selected!!.title)) set.remove(selected!!.title)
                        favorites = set
                        prefs.edit().putStringSet("favorites", set).apply()
                    }, { selected = null })
                } else {
                    when (page) {
                        "Start" -> HomeScreen(query, { query = it }, { selected = it }, { page = it })
                        "Szukaj" -> SearchScreen(query, { query = it }, { selected = it })
                        "Ulubione" -> TipList(tips.filter { favorites.contains(it.title) }, { selected = it })
                        "Notatki" -> NotesScreen(notes, { notes = it; prefs.edit().putString("notes", it).apply() })
                        "Forum" -> ForumScreen()
                    }
                }
                Spacer(Modifier.weight(1f))
                NavigationBar(containerColor = Color(0xFF101B15), contentColor = Paper) {
                    listOf("Start", "Szukaj", "Ulubione", "Notatki", "Forum").forEach { item ->
                        NavigationBarItem(
                            selected = page == item && selected == null,
                            onClick = { selected = null; page = item },
                            icon = {
                                Icon(when(item) {
                                    "Start" -> Icons.Default.Home
                                    "Szukaj" -> Icons.Default.Search
                                    "Ulubione" -> Icons.Default.Favorite
                                    "Notatki" -> Icons.Default.EditNote
                                    else -> Icons.Default.Groups
                                }, contentDescription = item)
                            },
                            label = { Text(item, fontSize = 10.sp) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(query: String, onQuery: (String) -> Unit, open: (Tip) -> Unit, go: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Moss), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("Witaj w terenie.", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Znajdź praktyczną poradę, nawet bez zasięgu.", color = Paper)
                Spacer(Modifier.height(14.dp))
                SearchBox(query, onQuery, Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Button(onClick = { go("Szukaj") }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) {
                    Text("Szukaj w poradniku", color = Forest)
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Kategorie", color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        val cats = listOf("🔥 Ogień", "🏕️ Biwak", "💧 Woda", "🍄 Jedzenie", "🪓 Bushcraft", "🧭 Nawigacja", "🆘 Survival", "🩹 Pierwsza pomoc")
        Column {
            cats.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth()) {
                    row.forEach { c ->
                        Card(Modifier.weight(1f).padding(4.dp).clickable { go("Szukaj") }, colors = CardDefaults.cardColors(containerColor = Color(0xFF263B2E))) {
                            Text(c, Modifier.padding(14.dp), color = Paper, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Polecane porady", color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        TipList(tips.take(4), open)
    }
}

@Composable
fun SearchScreen(query: String, onQuery: (String) -> Unit, open: (Tip) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text("Wyszukiwarka porad", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        SearchBox(query, onQuery, Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        val results = tips.filter {
            normalize("${it.title} ${it.category} ${it.summary} ${it.tags} ${it.best} ${it.alternatives}")
                .contains(normalize(query).trim())
        }
        Text("${results.size} wyników", color = Paper.copy(alpha = .7f), fontSize = 12.sp)
        TipList(results, open)
    }
}

fun normalize(s: String): String = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
    .replace("\\p{Mn}+".toRegex(), "").replace("ł", "l")

@Composable
fun SearchBox(value: String, onValue: (String) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().height(52.dp).padding(2.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(color = Paper, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxSize()) {
            Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Search, contentDescription = null, tint = Ink)
                Spacer(Modifier.width(8.dp))
                BasicTextField(value, onValue, Modifier.weight(1f), singleLine = true, decorationBox = { inner ->
                    if (value.isEmpty()) Text("Np. rozpałka, woda, biwak…", color = Color.Gray)
                    inner()
                })
                if (value.isNotEmpty()) Icon(Icons.Default.Close, contentDescription = "Wyczyść", tint = Ink,
                    modifier = Modifier.clickable { onValue("") })
            }
        }
    }
}

@Composable
fun TipList(list: List<Tip>, open: (Tip) -> Unit) {
    LazyColumn(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(list) { tip ->
            Card(Modifier.fillMaxWidth().clickable { open(tip) }, colors = CardDefaults.cardColors(containerColor = Color(0xFF263B2E))) {
                Column(Modifier.padding(14.dp)) {
                    Text(tip.category.uppercase(), color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(tip.title, color = Paper, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(tip.summary, color = Paper.copy(alpha = .78f), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun TipDetail(tip: Tip, isFav: Boolean, toggle: () -> Unit, back: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item {
            Text("‹ Wróć", color = Gold, modifier = Modifier.clickable { back() }.padding(vertical = 8.dp))
            Text(tip.category.uppercase(), color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(tip.title, color = Paper, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(tip.summary, color = Paper.copy(alpha = .8f), modifier = Modifier.padding(top = 6.dp, bottom = 12.dp))
            OutlinedButton(onClick = toggle) {
                Icon(if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = null)
                Spacer(Modifier.width(8.dp)); Text(if (isFav) "Zapisano w ulubionych" else "Dodaj do ulubionych")
            }
        }
        item { DetailSection("Najlepszy wybór", tip.best) }
        item { DetailSection("Alternatywy", tip.alternatives) }
        item { DetailSection("Jak postępować", tip.steps) }
        item { DetailSection("⚠️ Ważne bezpieczeństwo", tip.caution) }
    }
}

@Composable
fun DetailSection(title: String, body: String) {
    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF263B2E))) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(body, color = Paper, lineHeight = 21.sp)
        }
    }
}

@Composable
fun NotesScreen(notes: String, onChange: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Moje notatki", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text("Notatki zapisują się automatycznie w telefonie.", color = Paper.copy(alpha = .7f), fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = notes, onValueChange = onChange, modifier = Modifier.fillMaxSize(),
            placeholder = { Text("Lista sprzętu, plan wyprawy, własne patenty…") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Paper, unfocusedTextColor = Paper,
                focusedBorderColor = Gold, unfocusedBorderColor = Moss,
                focusedPlaceholderColor = Color.LightGray, unfocusedPlaceholderColor = Color.LightGray
            ))
    }
}

@Composable
fun ForumScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Forum Leśnego Zdzicha", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text("To będzie część internetowa aplikacji. Podręcznik, wyszukiwarka, ulubione i notatki działają już lokalnie, bez konta i bez internetu.", color = Paper)
        listOf("Miejscówki na biwak", "Patenty i konstrukcje", "Porady bushcraftowe", "Relacje z wypraw", "Pytania i odpowiedzi").forEach {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF263B2E))) {
                Text("🌲  $it", Modifier.fillMaxWidth().padding(15.dp), color = Paper, fontWeight = FontWeight.SemiBold)
            }
        }
        Text("Logowanie, publikowanie i synchronizacja wymagają późniejszego podłączenia bezpiecznego serwera. Nie udajemy, że forum działa offline.", color = Gold, fontSize = 12.sp)
    }
}
